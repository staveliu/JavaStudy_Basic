package oophomework3;

public class MyMath {
    public int add(int a,int b){
        return a + b;
    }

    public double add(int a,double b){
        return a + b;
    }

    public double add(double a,int b){
        return a + b;
    }

    public double add(double a,double b){
        return a + b;
    }

    public String add(String a,String b){
        return a + b ;
    }


    public int minus(int a,int b){
        return a - b;
    }

    public double minus(int a,double b){
        return a - b;
    }

    public double minus(double a,int b){
        return a - b;
    }

    public double minus(double a,double b){
        return a - b;
    }

    public int time(int a,int b){
        return a * b;
    }

    public double time(int a,double b){
        return a * b;
    }

    public double time(double a,int b){
        return a * b;
    }

    public double time(double a,double b){
        return a * b;
    }

    public int except(int a,int b){
        return a / b;
    }

    public double except(int a,double b){
        return a / b;
    }

    public double except(double a,int b){
        return a / b;
    }

    public double except(double a,double b){
        return a / b;
    }

}
