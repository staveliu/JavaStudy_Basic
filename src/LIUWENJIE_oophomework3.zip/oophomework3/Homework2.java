package oophomework3;

public class Homework2 {
    public static void main(String[] args) {
        Friends friend1 = new Friends("Linda","+8613788888888","Linda@stave.tech","Hunan Changsha","Stave","+8613787319525","admin@stave.tech","Hunan Changsha");
        friend1.display();
    }
}
