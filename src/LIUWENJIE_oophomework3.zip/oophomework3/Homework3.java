package oophomework3;

public class Homework3 {
    public static void main(String[] args){
        Person person1 = new Person("Stave","Male",20);
        person1.display();
        Person person2 = new Person("Lina","Female",18);
        person2.display();
        Person person3 = new Person("Pig","Male",21);
        person3.display();
    }
}
