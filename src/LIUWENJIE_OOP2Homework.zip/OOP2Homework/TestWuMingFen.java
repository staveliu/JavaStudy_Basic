package OOP2Homework;

public class TestWuMingFen {
    WuMingFen f1 = new WuMingFen("牛肉",3,true);
    WuMingFen f2 = new WuMingFen("牛肉",2);
    WuMingFen f3 = new WuMingFen();

}
