package oop_poly_hmk.dinner;

public class Homework2 {
    public static void main(String[] args){
        Person chinese1 = new Chinese("Stave");
        chinese1.Dinner_Time();
        Person foreign1 = new Foreigners("ppp");
        foreign1.Dinner_Time();
    }
}
