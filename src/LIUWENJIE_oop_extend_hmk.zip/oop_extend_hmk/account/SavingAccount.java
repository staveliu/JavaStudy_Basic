package oop_extend_hmk.account;

public class SavingAccount extends Account {
    public SavingAccount(int id, double balance) {
        super(id, balance);
    }
}
