package oop_extend_hmk.car;

public class Homework1 {
    public static void main(String[] args){
        CarHonda car1 = new CarHonda("Yellow");
        CarHonda car2 = new CarHonda();
        CarHonda car3 = new CarHonda("Slivery","Blue","Truck");
        car1.display();
        car2.display();
        car3.display();
    }
}
